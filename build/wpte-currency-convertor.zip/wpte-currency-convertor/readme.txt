=== Currency Convertor - WP Travel Engine ===
Plugin link: https://somewhere.com/
Tags: currency-convertor
Requires at least: 4.4.0
Tested up to: 5.5
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
goes on ...
