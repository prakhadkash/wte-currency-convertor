<?php
   /**
    * The template for displaying trips trip listing page
    *
    * @package Wp_Travel_Engine
    * @subpackage Wp_Travel_Engine/includes/templates
    * @since 1.0.0
    */
   	get_header(); ?>
    <div id="wte-crumbs">
        <?php
        do_action('wp_travel_engine_breadcrumb_holder');
        ?>
    </div>
    <?php
    $wte_trip_tax_post_args = array(
        'post_type'      => 'trip',
        'posts_per_page' => -1,
        'order'          => apply_filters('wpte_trip_listing_order','DESC'),
        'orderby'        => apply_filters('wpte_trip_listing_order_by','date'),
    );

    $options = get_option( 'wp_travel_engine_settings', array() );
    if( isset( $options['reorder']['flag'] ) ){
        $wte_trip_tax_post_args['order'] = 'ASC';
        $wte_trip_tax_post_args['orderby'] = 'menu_order';
    }
    
    $wte_trip_tax_post_qry = new WP_Query($wte_trip_tax_post_args);
    global $post;
    if($wte_trip_tax_post_qry->have_posts()) : ?>    
        <div id="wp-travel-trip-wrapper" class="trip-content-area" itemscope itemtype="http://schema.org/ItemList">
            <div class="page-header">
                <!-- <h1 class="page-title"><?php the_title(); ?></h1> -->
                <div class="page-feat-image">
                    <?php
                    $image_id = get_post_thumbnail_id( $post->ID );
                    $activities_banner_size = apply_filters('wp_travel_engine_template_banner_size', 'full');
                    echo wp_get_attachment_image ( $image_id, $activities_banner_size );
                    ?> 
                </div>
                <div class="page-content">
                    <p>
                        <?php  
                        $content = apply_filters('the_content', $post->post_content); 
                        echo $content;?>
                    </p>
                </div>
            </div>
            <div class="wp-travel-inner-wrapper">
                <div class="wp-travel-engine-archive-outer-wrap">                    
                    <?php
                        /**
                         * wp_travel_engine_archive_sidebar hook
                         * 
                         * @hooked wte_advanced_search_archive_sidebar - Trip Search addon
                         */
                        do_action( 'wp_travel_engine_archive_sidebar' );
                    ?>
                    <div class="wp-travel-engine-archive-repeater-wrap">
                        <?php 
                            /**
                             * Hook - wp_travel_engine_header_filters 
                             * Hook for the new archive filters on trip archive page.
                             * @hooked - wp_travel_engine_header_filters_template.
                             */
                            do_action( 'wp_travel_engine_header_filters' );
                        ?>
                        <div class="wte-category-outer-wrap">
                        <?php
                            $j = 1;
                            $view_mode = wp_travel_engine_get_archive_view_mode();
                            if ( 'grid' === $view_mode ) {
                                $view_class = class_exists( 'Wte_Advanced_Search' ) ? 'col-2 category-grid' : 'col-3 category-grid';
                            } else {
                                $view_class = 'category-list';
                            }
                            echo '<div class="category-main-wrap '. esc_attr( $view_class ) .'">';
                                while( $wte_trip_tax_post_qry->have_posts() ) : $wte_trip_tax_post_qry->the_post();
                                    $details = wte_get_trip_details( get_the_ID() );
                                    $details['j'] = $j;
                                    wte_get_template( 'content-'.$view_mode.'.php', $details );
                                    $j++;
                                endwhile;
                                wp_reset_postdata();
                            echo '</div>';
                        ?>
                        </div>
                        <div id="loader" style="display: none">
                            <div class="table">
                                <div class="table-grid">
                                    <div class="table-cell">
                                        <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    endif;
get_footer();