<?php
/**
 * Email footer template.
 */
?>
						<div class="footer">
							<table width="100%">
								<tr>
									<td class="aligncenter content-block"><?php _e( 'Powered By:', 'wp-travel-engine' ); ?> <a href="https://wptravelengine.com"><?php _e( 'WP Travel Engine', 'wp-travel-engine' ); ?></td>
								</tr>
							</table>
						</div>
					</div>
				</td>
				<td>
				</td>
			</tr>
		</table>
	</body>
</html>
<?php
