<?php
/**
 * Number field template.
 * 
 * @package Wp Travel Engine
 */
class WP_Travel_Engine_Form_Field_Number extends WP_Travel_Engine_Form_Field_Text {
    
    // Defind field type.
    protected $field_type = 'number';

}
