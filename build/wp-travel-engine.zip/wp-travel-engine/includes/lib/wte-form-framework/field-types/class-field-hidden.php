<?php
/**
 * Hidden field template.
 * 
 * @package Wp Travel Engine
 */
class WP_Travel_Engine_Form_Field_Hidden extends WP_Travel_Engine_Form_Field_Text {
    
    // Defind field type.
    protected $field_type = 'hidden';

}
