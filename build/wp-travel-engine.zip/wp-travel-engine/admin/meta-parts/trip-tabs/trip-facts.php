<?php
/**
 * Trip Facts Template.
 */
global $post;
// Get post ID.
if ( ! is_object( $post ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
    $post_id  = $_POST['post_id'];
    $next_tab = $_POST['next_tab']; 
} else {
    $post_id = $post->ID;
}
// Get settings meta.
$wp_travel_engine_setting = get_post_meta( $post_id, 'wp_travel_engine_setting', true );

// Global settings.
$wp_travel_engine_option_settings = get_option( 'wp_travel_engine_settings', true );

$trip_facts_title = isset( $wp_travel_engine_setting['trip_facts_title'] ) ? $wp_travel_engine_setting['trip_facts_title'] : '';

$page_shortcode     = '[Trip_Info_Shortcode id='."'".$post_id."'".']';
$template_shortcode = "&lt;?php echo do_shortcode('[Trip_Info_Shortcode id=".$post_id."]'); ?&gt;";
?>

    <div class="wpte-field wpte-text wpte-floated">
        <label class="wpte-field-label"><?php esc_html_e( 'Section Title', 'wp-travel-engine' ); ?></label>
        <input type="text" name="wp_travel_engine_setting[trip_facts_title]" value="<?php echo esc_attr( $trip_facts_title ); ?>" placeholder="<?php esc_attr_e( 'Enter Trip Info Title', 'wp-travel-engine' ); ?>">
        <span class="wpte-tooltip"><?php esc_html_e( 'Enter the title to display inside the tab section of Trip Facts section.', 'wp-travel-engine' ) ?></span>
    </div>
    <div class="wpte-info-block">
        <b><?php esc_html_e( 'Note:', 'wp-travel-engine' ); ?></b>
        <p><?php _e( sprintf('You can use this shortcode <b>%1$s</b> to display Trip Info of this trip in posts/pages/tabs or use this snippet <b>%2$s</b> to display Trip Info in templates.',$page_shortcode, $template_shortcode),'wp-travel-engine');?></p>
    </div>

    <div class="wpte-field wpte-multi-fields wpte-floated">
    <?php 
        if ( isset( $wp_travel_engine_option_settings['trip_facts'] ) ) {
			$trip_facts = $wp_travel_engine_option_settings['trip_facts'];
    ?>
            <label class="wpte-field-label"><?php _e( 'Trip info selection', 'wp-travel-engine' ); ?></label>
            <div class="wpte-floated">
                <select id="wte_global_trip_facts" data-nonce="<?php echo wp_create_nonce('trip-info-nonce') ?>" name="wte_global_trip_facts" data-placeholder="<?php esc_attr_e( 'Info Type&hellip;', 'wp-travel-engine' ); ?>">
                    <option value=""><?php _e( 'Select Trip Fact', 'wp-travel-engine' ) ?></option>
                    <?php 
                        foreach ( $trip_facts['field_type'] as $key => $value ) {
                            $id = $wp_travel_engine_option_settings['trip_facts']['field_id'][$key];
                            echo '<option value="' .esc_attr($id). '">' . esc_html( $id ) . '</option>';
                        }
                    ?>
                </select>
                <input type="button" class="button button-small add-info" value="<?php esc_attr_e( 'Add Fact', 'wp-travel-engine' ); ?>">
            </div>
            <span class="wpte-tooltip"><?php _e( 'Select the trip fact title and click on add fact button to enter trip fact data.', 'wp-travel-engine' ) ?></span>
    <?php 
        } else {
            esc_html_e( 'Global Trip Info not found. Please add trip info in the global settings page first.', 'wp-travel-engine' );
        } ?>
    </div>
    <input type="hidden" name="wp_travel_engine_setting[trip_facts]" value="false">
    <div class="wpte-repeater-wrap wpte-trip-facts-hldr">
        <?php
			if ( isset( $wp_travel_engine_setting['trip_facts'] ) && is_array( $wp_travel_engine_setting['trip_facts'] ) ){
				$wp_travel_engine_option_settings = get_option( 'wp_travel_engine_settings', true );
				foreach ( $wp_travel_engine_setting['trip_facts']['field_type'] as $key => $value ) {
					if ( isset( $wp_travel_engine_option_settings['trip_facts']['fid'][$key] ) ) {
                        $id = $wp_travel_engine_option_settings['trip_facts']['field_id'][$key];
        ?>
                        <div class="wpte-repeater-block wpte-sortable wpte-trip-fact-row">
                            <div class="wpte-field wpte-floated">
                                <label class="wpte-field-label" for="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]"><?php _e($id.': ','wp-travel-engine');?></label>
                                <input type="hidden" name="wp_travel_engine_setting[trip_facts][field_id][<?php echo $key;?>]" value="<?php echo $id;?>">
								<input type="hidden" name="wp_travel_engine_setting[trip_facts][field_type][<?php echo $key;?>]" value="<?php echo $wp_travel_engine_option_settings['trip_facts']['field_type'][$key];?>">
                                <?php 
                                    switch ($value) {
                                        case 'select': 
                                            $options = $trip_facts['select_options'][$key];
                                            $options = explode( ',', $options );
                                            $selected_field = isset( $wp_travel_engine_postmeta_setting['trip_facts'][$key][$key] ) ? esc_attr( $wp_travel_engine_postmeta_setting['trip_facts'][$key][$key] ):'';
                                            ?>
                                            <select id="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" name="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" data-placeholder="<?php esc_attr_e( 'Choose a field type&hellip;', 'wp-travel-engine' ); ?>" class="wc-enhanced-select" >
                                            <option value=" "><?php _e( 'Choose input type&hellip;', 'wp-travel-engine' ); ?></option>
                                            <?php
                                            foreach ( $options as $key => $val ) {
                                            if( isset($val) && $val !='' ){												
                                            $val = trim($val);
                                            echo '<option value="' .( !empty($val)?esc_attr( $val ):"Please select")  . '" ' . selected( $selected_field, $val, false ) . '>' . esc_html( $val ) . '</option>';
                                            }
                                            }
                                            ?>
                                            </select>
                                            <?php
                                        break;
                                        
                                        case 'duration' :
                                            ?>
                                                <input type="number" min="1" placeholder = "<?php _e('Number of days','wp-travel-engine');?>" class="duration" id="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" name="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" value="<?php echo isset($wp_travel_engine_setting['trip_facts'][$key][$key]) ? esc_attr( $wp_travel_engine_setting['trip_facts'][$key][$key] ): '';?>"/>
                                            <?php
                                        break;

                                        case 'number':
                                            ?>
                                                <input  type="number" min="1" id="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" name="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" value="<?php echo isset($wp_travel_engine_setting['trip_facts'][$key][$key]) ? esc_attr( $wp_travel_engine_setting['trip_facts'][$key][$key] ): '';?>" placeholder="<?php echo isset($trip_facts['input_placeholder'][$key]) ? esc_attr( $trip_facts['input_placeholder'][$key] ): '';?>" >
                                            <?php
                                        break;

                                        case 'text' :
                                            ?>
                                                <input type="text" id="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" name="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" value="<?php echo isset($wp_travel_engine_setting['trip_facts'][$key][$key]) ? esc_attr( $wp_travel_engine_setting['trip_facts'][$key][$key] ): '';?>" placeholder="<?php echo isset($trip_facts['input_placeholder'][$key]) ? esc_attr( $trip_facts['input_placeholder'][$key] ): '';?>">
                                            <?php
                                        break;

                                        case 'textarea';
                                            ?>
                                                <textarea id="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" name="wp_travel_engine_setting[trip_facts][<?php echo $key;?>][<?php echo $key;?>]" placeholder="<?php echo isset($trip_facts['input_placeholder'][$key]) ? $trip_facts['input_placeholder'][$key]: '';?>" ><?php echo isset($wp_travel_engine_setting['trip_facts'][$key][$key]) ? $wp_travel_engine_setting['trip_facts'][$key][$key]: '';?></textarea>
                                            <?php
                                        break;
                                    }
                                ?>
                                <button class="wpte-delete wpte-remove-trp-fact"></button>
                            </div>
                        </div>
                    <?php 
                    }
                }
            }
        ?>
    </div> <!-- .wpte-repeater-wrap -->

    <?php if ( $next_tab ) : ?>
        <div class="wpte-field wpte-submit">
            <input data-tab="facts" data-post-id="<?php echo esc_attr( $post_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'wpte-trip-tab-save-continue' ) ); ?>" data-next-tab="<?php echo esc_attr( $next_tab['callback_function'] ); ?>" class="wpte_save_continue_link" type="submit" name="wpte_trip_tabs_save_continue" value="<?php _e( 'Save &amp; Continue', 'wp-travel-engine' ); ?>">
        </div>
    <?php endif;